﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ControlMiner
{
    public static class AnchorKeyboard
    {
       
        public delegate IntPtr HookDefault(int nCode, IntPtr wParam, IntPtr lParam);
        public delegate void HookHandler(IntPtr wParam, IntPtr lParam);

        private static IntPtr currentHook = IntPtr.Zero;
        private static HookDefault hookDefault;
        private static HookHandler hookHandler;

        /// <summary>
        /// Creates windows hook
        /// </summary>
        /// <param name="hookHndlr">Function for handling hooked events</param>
        public static void CreateHook(HookHandler hookHndlr)
        {
            Process _this = Process.GetCurrentProcess();
            ProcessModule mod = _this.MainModule;
            hookDefault = HookFunc;
            hookHandler = hookHndlr;

            currentHook = NativeMethods.SetWindowsHookEx(13, hookDefault, NativeMethods.GetModuleHandle(mod.ModuleName), 0);
        }

        /// <summary>
        /// Default hook call, which analyses pressed keys
        /// </summary>
        public static IntPtr HookFunc(int nCode, IntPtr wParam, IntPtr lParam)
        {
            int iwParam = wParam.ToInt32();
            if (nCode >= 0 &&
                (iwParam == 0x100 || iwParam == 0x104)) //0x100 = WM_KEYDOWN, 0x104 = WM_SYSKEYDOWN
            {
                hookHandler(wParam, lParam);
            }

            return NativeMethods.CallNextHookEx(currentHook, nCode, wParam, lParam);
        }

        /// <summary>
        /// Destroys currently set hook
        /// </summary>
        public static bool DestroyHook()
        {
            return NativeMethods.UnhookWindowsHookEx(currentHook);
        }

    }
}
