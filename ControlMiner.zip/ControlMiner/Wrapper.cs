﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ControlMiner
{
    public class Wrapper
    {
        const int WM_GETTEXT = 0x000D;
        const int WM_GETTEXTLENGTH = 0x000E;
        const int LB_SETCURSEL = 0x0186;
        const int LB_GETCURSEL = 0x0188;
        const int LB_GETCOUNT = 0x018B;
        const int LB_GETTEXT = 0x0189;

        NativeMethods.GUITHREADINFO guiInfo;                     // To store GUI Thread Information
        Point caretPosition;                     // To store Caret Position  
        ControlMiner.NativeMethods.Rect NotepadRect;



        public static string GetControlText(IntPtr currentHandle)
        {
            IntPtr hWnd = FocusedControlInActiveWindow(currentHandle);
            StringBuilder title = new StringBuilder();

            // Get the size of the string required to hold the window title. 
            Int32 size = NativeMethods.SendMessage((int)hWnd, WM_GETTEXTLENGTH, 0, 0).ToInt32();

            // If the return is 0, there is no title. 
            if (size > 0)
            {
                title = new StringBuilder(size + 1);

                NativeMethods.SendMessage(hWnd, (int)WM_GETTEXT, title.Capacity, title);


            }
            return title.ToString();
        }


        public static List<string> GetListBoxContents(IntPtr currentHandle, out string selectedText)
        {
            IntPtr hWnd = FocusedControlInActiveWindow(currentHandle);
            int cnt = (int)NativeMethods.SendMessage(hWnd, LB_GETCOUNT, IntPtr.Zero, null);
            int selectedindex = (int)NativeMethods.SendMessage(hWnd, (uint)LB_GETCURSEL, IntPtr.Zero, null);
            List<string> listBoxContent = new List<string>();
            if (cnt > 0)
            {

                for (int i = 0; i < cnt; i++)
                {
                    StringBuilder sb = new StringBuilder(256);
                    IntPtr getText = NativeMethods.SendMessage(hWnd, LB_GETTEXT, (IntPtr)i, sb);
                    listBoxContent.Add(sb.ToString());
                }
            }
            selectedText = (selectedindex != -1 && listBoxContent.Count != 0) ? listBoxContent[selectedindex].ToString() : "";
            return listBoxContent;
        }


        private static IntPtr FocusedControlInActiveWindow(IntPtr handle)
        {
            IntPtr activeWindowHandle = NativeMethods.GetForegroundWindow();

            IntPtr activeWindowThread = NativeMethods.GetWindowThreadProcessId(activeWindowHandle, IntPtr.Zero);
            IntPtr thisWindowThread = NativeMethods.GetWindowThreadProcessId(handle, IntPtr.Zero);

            NativeMethods.AttachThreadInput(activeWindowThread, thisWindowThread, true);
            IntPtr focusedControlHandle = NativeMethods.GetFocus();
            NativeMethods.AttachThreadInput(activeWindowThread, thisWindowThread, false);

            return focusedControlHandle;
        }

        /// <summary>
        /// Get the caret position
        /// </summary>
        public void GetCaretPosition()
        {
            guiInfo = new NativeMethods.GUITHREADINFO();
            guiInfo.cbSize = (uint)Marshal.SizeOf(guiInfo);

            // Get GuiThreadInfo into guiInfo
            NativeMethods.GetGUIThreadInfo(0, out guiInfo);
        }

        public void EvaluateCaretPosition()
        {
            caretPosition = new Point();

            // Fetch GUITHREADINFO
            GetCaretPosition();

            caretPosition.X = (int)guiInfo.rcCaret.Left + 25;
            caretPosition.Y = (int)guiInfo.rcCaret.Bottom + 25;

            NativeMethods.ClientToScreen(guiInfo.hwndCaret, out caretPosition);
        }

        public NativeMethods.Rect GetWindow(string applicationName)
        {
            IntPtr hWnd = NativeMethods.FindWindow(null, applicationName); //Calculator is Windows calc title text
            NotepadRect = new NativeMethods.Rect();
            NativeMethods.GetWindowRect(hWnd, ref NotepadRect);
            NotepadRect.Width = NotepadRect.Right - NotepadRect.Left + 1;
            NotepadRect.Height = NotepadRect.Bottom - NotepadRect.Top + 1;

            return NotepadRect;
        }

        public bool IsApplicationActive(string applicationName)
        {
            bool applicationFound = false;
            IntPtr handle = IntPtr.Zero;
            handle = NativeMethods.GetForegroundWindow();
            StringBuilder Buff = new StringBuilder(256);

            if (NativeMethods.GetWindowText(handle, Buff, 256) > 0 && Buff.ToString().Equals(applicationName))
            {
                applicationFound = true;
            }
            return applicationFound;
        }
    }
}
