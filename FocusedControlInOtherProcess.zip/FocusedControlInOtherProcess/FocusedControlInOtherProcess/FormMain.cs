﻿using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace FocusedControlInOtherProcess
{
   

    public partial class FormMain : Form
    {
        [DllImport("user32.dll")]
        static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        static extern IntPtr GetWindowThreadProcessId(IntPtr hWnd, IntPtr ProcessId);

        [DllImport("user32.dll")]
        static extern IntPtr AttachThreadInput(IntPtr idAttach, IntPtr idAttachTo, bool fAttach);

        [DllImport("user32.dll")]
        static extern IntPtr GetFocus();

        [DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string lpszWindow);

        private delegate bool EnumWindowProc(IntPtr hwnd, IntPtr lParam);

        [DllImport("user32")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool EnumChildWindows(IntPtr window, EnumWindowProc callback, IntPtr lParam);

        [DllImport("user32.dll")]
        static extern int GetWindowText(int hWnd, StringBuilder text, int count);

        private IntPtr _MainHandle;

        public List<IntPtr> GetAllChildHandles()
        {
            List<IntPtr> childHandles = new List<IntPtr>();

            GCHandle gcChildhandlesList = GCHandle.Alloc(childHandles);
            IntPtr pointerChildHandlesList = GCHandle.ToIntPtr(gcChildhandlesList);

            try
            {
                EnumWindowProc childProc = new EnumWindowProc(EnumWindow);
                EnumChildWindows(this._MainHandle, childProc, pointerChildHandlesList);
            }
            finally
            {
                gcChildhandlesList.Free();
            }

            return childHandles;
        }

        private bool EnumWindow(IntPtr hWnd, IntPtr lParam)
        {
            GCHandle gcChildhandlesList = GCHandle.FromIntPtr(lParam);

            if (gcChildhandlesList == null || gcChildhandlesList.Target == null)
            {
                return false;
            }

            List<IntPtr> childHandles = gcChildhandlesList.Target as List<IntPtr>;
            childHandles.Add(hWnd);
            StringBuilder sb = new StringBuilder(256);
            GetWindowText((int)hWnd, sb, 256);
            // Find window handle
            //label11.Text += sb.ToString();

            return true;
        }

        public FormMain()
        {
            InitializeComponent();
            //TSManager.OpenServer("dlfdes017w");
            var list = TSManager.ListSessions("dlfdes017w");

        }

        private void timerUpdate_Tick(object sender, EventArgs e)
        {
            labelHandle.Text = "hWnd: " + FocusedControlInActiveWindow().ToString();
            var allhandles = GetAllChildHandles();
            if (labelHandle.Text == "hWnd: 1378822")
            {
                lblCount.Text = "Count:" + allhandles.Count;
                WindowText wT = new WindowText();

                foreach (var child in allhandles)
                {
                    File.AppendAllText("log.txt", wT.GetControlText(child) + Environment.NewLine);
                }
            }
        }

        private IntPtr FocusedControlInActiveWindow()
        {
            IntPtr activeWindowHandle = GetForegroundWindow();
            _MainHandle = activeWindowHandle;
            IntPtr activeWindowThread = GetWindowThreadProcessId(activeWindowHandle, IntPtr.Zero);
            IntPtr thisWindowThread = GetWindowThreadProcessId(this.Handle, IntPtr.Zero);

            AttachThreadInput(activeWindowThread, thisWindowThread, true);
            IntPtr focusedControlHandle = GetFocus();
            AttachThreadInput(activeWindowThread, thisWindowThread, false);

            return focusedControlHandle;
        }
    }
}
