﻿using ControlMiner;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProcessMinifier
{
    public partial class MainForm : Form
    {
        Wrapper wrapper = null;
        string appName = string.Empty;
        NativeMethods.Rect rect = new NativeMethods.Rect();
        public MainForm()
        {
            InitializeComponent();
        }

        private void start_Click(object sender, EventArgs e)
        {
            appName = ApplicationName.Text.Trim();
            wrapper = new Wrapper(appName, this.Handle);

            AnchorKeyboard.CreateHook(wrapper.ProcessHook);
            wrapper.SendMessageToWeb += Wrapper_SendMessageToWeb;
        }

        private void Wrapper_SendMessageToWeb(string position, string message)
        {
             TextControl.Text = position + "," + message;
        }

        private void stop_Click(object sender, EventArgs e)
        {
            AnchorKeyboard.DestroyHook();
        }

        private void watcher_Tick(object sender, EventArgs e)
        {
            
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            ApplicationName.Text = "Student";
        }
    }
}
