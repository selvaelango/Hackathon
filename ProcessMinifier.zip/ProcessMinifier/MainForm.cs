﻿using ControlMiner;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProcessMinifier
{
    public partial class MainForm : Form
    {
        Wrapper wrapper = new Wrapper();

        public MainForm()
        {
            InitializeComponent();
        }

        private void start_Click(object sender, EventArgs e)
        {
            //wP.PrepareFile();
            //AnchorKeyboard.CreateHook(wP.ProcessHook);
        }

        private void stop_Click(object sender, EventArgs e)
        {
            //AnchorKeyboard.DestroyHook();
            //wP.ActionFlush();
        }

        private void watcher_Tick(object sender, EventArgs e)
        {
            string appName = ApplicationName.Text.Trim();

            if (!string.IsNullOrEmpty(appName))
            {
                var rec = wrapper.GetWindow(appName);
                if (wrapper.IsApplicationActive(appName))
                {
                    TextControl.Text = Wrapper.GetControlText(this.Handle);

                    string selectedItem = string.Empty;
                    Wrapper.GetListBoxContents(this.Handle, out selectedItem);

                    ListComboControl.Text = selectedItem;
                }
            }
        }
    }
}
