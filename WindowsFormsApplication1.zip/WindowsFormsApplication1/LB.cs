﻿public enum LB
{
    /// <summary>
    ///   Adds a string to a list box. If the list box does not have the LBS_SORT style, the string is added to the end of the list. Otherwise, the string is inserted into the list and the list is sorted.
    ///   wParam-This parameter is not used.
    ///   lParam-A pointer to the null-terminated string that is to be added. If the list box has an owner-drawn style but not the LBS_HASSTRINGS style, this parameter is stored as item data instead of a string. You can send the LB_GETITEMDATA and LB_SETITEMDATA messages to retrieve or modify the item data.
    ///   Return value-The return value is the zero-based index of the string in the list box. If an error occurs, the return value is LB_ERR. If there is insufficient space to store the new string, the return value is LB_ERRSPACE.
    /// </summary>
    LB_ADDSTRING = 0x0180,

    /* Multi-Select Only */
    /// <summary>
    ///   Selects an item in a multiple-selection list box and, if necessary, scrolls the item into view
    ///   wParam  Specifies how to set the selection. If this parameter is TRUE, the item is selected and highlighted; if it is FALSE, the highlight is removed and the item is no longer selected. 
    ///   lParam Specifies the zero-based index of the item to set. If this parameter is –1, the selection is added to or removed from all items, depending on the value of wParam, and no scrolling occurs. 
    ///   Return Value-If an error occurs, the return value is LB_ERR. 
    ///   Remarks-Use this message only with multiple-selection list boxes.
    /// </summary>
    LB_SETSEL = 0x0185,

    ///<summary>
    ///  Fills a buffer with an array of integers that specify the item numbers of selected items in a multiple-selection list box
    ///  wParam- The maximum number of selected items whose item numbers are to be placed in the buffer. 
    ///  lParam-A pointer to a buffer large enough for the number of integers specified by the wParam parameter. 
    ///  Return-The return value is the number of items placed in the buffer. If the list box is a single-selection list box, the return value is LB_ERR.
    ///</summary>
    LB_GETSELITEMS = 0x0191,

    /// <summary>
    ///   Gets the total number of selected items in a multiple-selection list box
    ///   wParam and lParam-Not used; must be zero. 
    ///   Return Value-The return value is the count of selected items in the list box. If the list box is a single-selection list box, the return value is LB_ERR.
    /// </summary>
    LB_GETSELCOUNT = 0x0190,

    /* Single Select Only */
    /// <summary>
    ///   Gets the index of the currently selected item, if any, in a single-selection list box
    ///   wParam and lParam Not used; must be zero. 
    ///   Return Value-In a single-selection list box, the return value is the zero-based index of the currently selected item. If there is no selection, the return value is LB_ERR.
    /// </summary>
    LB_GETCURSEL = 0x0188,

    /// <summary>
    ///   wParam The zero-based index of the item before the first item to be searched. When the search reaches the bottom of the list box, it continues from the top of the list box back to the item specified by the wParam parameter. If wParam is –1, the entire list box is searched from the beginning. 
    ///   lParam A pointer to the null-terminated string that contains the prefix for which to search. The search is case independent
    ///   Return Value If the search is successful, the return value is the index of the selected item. If the search is unsuccessful,LB_ERR
    ///   Use this message only with single-selection list boxes. You cannot use it to set or remove a selection in a multiple-selection list box
    /// </summary>
    LB_SELECTSTRING = 0x018C,

    /* Either */
    ///<summary>
    ///  Selects a string and scrolls it into view, if necessary. When the new string is selected, the list box removes the highlight from the previously selected string. 
    ///  wParam Specifies the zero-based index of the string that is selected. If this parameter is -1, the list box is set to have no selection. 
    ///  lParam not used
    ///</summary>
    LB_SETCURSEL = 0x0186,

    ///<summary>
    ///  Finds the first string in a list box that begins with the specified string
    ///  wParam The zero-based index of the item before the first item to be searched. When the search reaches the bottom of the list box, it continues searching from the top of the list box back to the item specified by the wParam parameter. If wParam is –1, the entire list box is searched from the beginning. 
    ///  lParam A pointer to the null-terminated string that contains the string for which to search. The search is case independent, so this string can contain any combination of uppercase and lowercase letters. 
    ///  Return Value-The return value is the index of the matching item, or LB_ERR if the search was unsuccessful.
    ///</summary>
    LB_FINDSTRING = 0x018F,

    /// <summary>
    ///   Gets the number of items in a list box
    ///   wParam and lParam-zero
    ///   The return value is the number of items in the list box, or LB_ERR if an error occurs
    /// </summary>
    LB_GETCOUNT = 0x018B,

    ///<summary>
    ///  Gets the selection state of an item
    ///  wParam The zero-based index of the item
    ///  lParam This parameter is not used
    ///  Return Value-If an item is selected, the return value is greater than zero; otherwise, it is zero. If an error occurs, the return value is LB_ERR.
    ///</summary>
    LB_GETSEL = 0x0187,

    ///<summary>
    ///  Gets a string from a list box. 
    ///  wParam The zero-based index of the string to retrieve. 
    ///  lParam A pointer to the buffer that will receive the string; The buffer must have sufficient space for the string and a terminating null character.
    ///  Return Value length of the string, in TCHARs, excluding the terminating null character.
    ///</summary>
    LB_GETTEXT = 0x0189,

    /// <summary>
    ///   Removes all items from a list box
    /// </summary>
    LB_RESETCONTENT = 0x0184,

    /// <summary>
    /// Sets the width, in pixels, by which a list box can be scrolled horizontally
    /// (the scrollable width). If the width of the list box is smaller than this
    /// value, the horizontal scroll bar horizontally scrolls items in the list box.
    /// If the width of the list box is equal to or greater than this value, the
    /// horizontal scroll bar is hidden.
    /// </summary>
    LB_SETHORIZONTALEXTENT = 0x0194,

    /// <summary>
    /// Gets the width, in pixels, that a list box can be scrolled horizontally
    /// (the scrollable width) if the list box has a horizontal scroll bar. 
    /// </summary>
    LB_GETHORIZONTALEXTENT = 0x0193,

    /// <summary>
    /// Gets the index of the first visible item in a list box. Initially the item
    /// with index 0 is at the top of the list box, but if the list box contents have
    /// been scrolled another item may be at the top. The first visible item in a
    /// multiple-column list box is the top-left item.
    /// </summary>
    LB_GETTOPINDEX = 0x018E,

    /// <summary>
    /// Ensures that the specified item in a list box is visible.
    /// </summary>
    LB_SETTOPINDEX = 0x0197,

    /// <summary>
    /// Inserts a string or item data into a list box. Unlike the LB_ADDSTRING
    /// message, the LB_INSERTSTRING message does not cause a list with the
    /// LBS_SORT style to be sorted.
    /// </summary>
    LB_INSERTSTRING = 0x0181,

    /// <summary>
    /// Deletes a string in a list box.
    /// </summary>
    LB_DELETESTRING = 0x0182,

    /// <summary>
    /// Gets the application-defined value associated with the specified list box item.
    /// </summary>
    LB_GETITEMDATA = 0x0199
}